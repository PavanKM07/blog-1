let firebaseConfig = {
    apiKey: "AIzaSyDamFwaiMJ9e5XCZiSIB26vBmbuD-CguB4",

    authDomain: "blog-482cc.firebaseapp.com",

    projectId: "blog-482cc",

    storageBucket: "blog-482cc.appspot.com",

    messagingSenderId: "624040410219",

    appId: "1:624040410219:web:e4c0f61931ed1dec57c52e",

    measurementId: "G-Q20JH92Q49"

};

firebase.initializeApp(firebaseConfig);

let db = firebase.firestore();